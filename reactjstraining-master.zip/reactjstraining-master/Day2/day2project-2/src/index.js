import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";

import MainApplication from "./components/MainApplication"

import "./index.css";

ReactDOM.render(
  <BrowserRouter><MainApplication /></BrowserRouter>,
  document.getElementById("app")
);
