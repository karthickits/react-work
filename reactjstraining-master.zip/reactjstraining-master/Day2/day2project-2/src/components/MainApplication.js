import React from "react";
import { Switch, Route } from "react-router-dom";
import LoginComponent from "./LoginComponent";
import LogoutComponent from "./LogoutComponent";
import DepartmentComponent from "./department/DepartmentComponent";
import EmployeeComponent from "./employee/EmployeeComponent";
import MenuComponent from "./common/MenuComponent";
import HeaderComponent from "./common/HeaderComponent"

class MainApplication extends React.Component {
  render() {
    return (<div class="main"><HeaderComponent/><MenuComponent />
      <section class="content">
        <Switch>
          <Route path="/" exact component={LoginComponent} />
          <Route path="/department" exact component={DepartmentComponent} />
          <Route path="/employee" exact component={EmployeeComponent} />
          <Route path="/logout" exact component={LogoutComponent} />
          <Route
            path="*"
            render={() => {
              return <h1>404 - Page Not Found !</h1>;
            }}
          />
        </Switch>
      </section></div>
    );
  }
}

export default MainApplication;
