import React from "react";

class EmployeeComponent extends React.Component {
  render() {
    return (
      <div class="content">
        <h1>Employee</h1>
        <form action="">
          <div>
            <input type="button" value="Create" />
            <input type="button" value="Update" />
            <input type="button" value="Delete" />
          </div>
          <div>
            <table id="tab">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>&nbsp;</th>
                </tr>
              </thead>

              <tbody>
                <tr>
                  <td>101</td>
                  <td>Employee 1</td>
                  <td>
                    <input name="employee" type="radio" />
                  </td>
                </tr>
                <tr>
                  <td>102</td>
                  <td>Employee 2</td>
                  <td>
                    <input name="employee" type="radio" />
                  </td>
                </tr>
                <tr>
                  <td>103</td>
                  <td>Employee 3</td>
                  <td>
                    <input name="employee" type="radio" />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    );
  }
}

export default EmployeeComponent;
