import React from "react";
import { Link } from "react-router-dom";

class LogoutComponent extends React.Component {
  render() {
    return (
      <div>
            <h1>Logged out successful !<br />
            <Link to="/" >click to login</Link></h1>
        {/* <Redirect to="/" />{" "} */}
      </div>
    );
  }
}

export default LogoutComponent;