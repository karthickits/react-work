import React from "react";

class HeaderComponent extends React.Component {
  render() {
    return (
      <header class="header">
        <h1>Employee Database</h1>
      </header>
    );
  }
}

export default HeaderComponent;
