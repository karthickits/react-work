import React from "react";
import { Link } from "react-router-dom";

class MenuComponent extends React.Component {

    render() {
      return  <nav class="nav">
            <div> <Link to="/department" >Department</Link>{/*  <a href="#">Department</a> */}</div>
            <div><Link to="/employee" >Employee</Link>{/* <a href="#">Employee</a> */}</div>
            <div><Link to="/logout" >Logout</Link>{/* <a href="#">Logout</a> */}</div>
        </nav>;
    }

}

export default MenuComponent;