import React from "react";
import ReactDOM from "react-dom";

import "./index.css";

import Calc from "./lib/calculator";

import * as MyConstants from "./lib/commonfs";

import { PI, CURRENCY } from "./lib/commonfs";

import MyClock from "./components/myclock";

import DynaState from "./components/dynastate";

import AppComs from "./components/appcoms";

import ListingComp from "./components/listingcoms";

import FormSubmission from "./components/formsubmission";

const cl = new Calc();
console.log(cl.add(MyConstants.PI, 43));

ReactDOM.render(
  <div>
    <h1>
      <MyClock /> <br />
      Give me {CURRENCY} {cl.add(PI, 43)}{" "}
    </h1>
    <br />
        <DynaState /> <br /><br /><AppComs /> <br /><br /><ListingComp />
        <br /><br /><FormSubmission />
  </div>,
  document.getElementById("app")
);
