import React from "react";

function FormItem(props) {
  return (
    <div>
      <input
        type="button"
        value="Green"
        onClick={() => {
          props.setColor("Green"); // passing value from child to parent
        }}
      />
      <input
        type="button"
        value="Red"
        onClick={() => {
          props.setColor("red"); // passing value from child to parent
        }}
      />
      <input
        type="button"
        value="Blue"
        onClick={() => {
          props.setColor("blue"); // passing value from child to parent
        }}
          />  
          <input
              type="text"
              value={props.textVal}
              onClick={() => {
                props.textChanged(); // passing value from child to parent
              }}
      />
            
    </div>
  );
}

export default FormItem;