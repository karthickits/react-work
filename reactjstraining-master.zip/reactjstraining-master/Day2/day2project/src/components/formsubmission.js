import React from "react";

class FormSubmission extends React.Component {
  constructor() {
    super();

    this.state = {
      textVal: "",
      radiogroup_m: "",
      radiogroup_f: ""
    };

    this.textChanged = this.textChanged.bind(this);
    this.radioGroupMSelected = this.radioGroupMSelected.bind(this);
    this.radioGroupFSelected = this.radioGroupFSelected.bind(this);
    this.formSumitted = this.formSumitted.bind(this);
  }

  textChanged(eventObj) {
    this.setState({ textVal: eventObj.target.value });
  }

  radioGroupMSelected(eventObj) {
    this.setState({ radiogroup_m: eventObj.target.checked });
  }

  radioGroupFSelected(eventObj) {
    this.setState({ radiogroup_f: eventObj.target.checked });
  }

  formSumitted() {
    console.log(
      this.radiogroup_m.checked +
        " - " +
        this.radiogroup_f.checked +
        " - " +
        this.state.textVal
    );
  }

  render() {
    return (
      <form>
        Name:{" "}
        <input
          type="text"
          value={this.state.textVal}
          onChange={this.textChanged}
        />
        <br />
        Gender: <br />
        <input
          type="radio"
          name="gender"
          value="male"
          ref={node => {
            this.radiogroup_m = node;
          }}
        />
        Male
        <br />
        <input
          type="radio"
          name="gender"
          value="female"
          ref={node => {
            this.radiogroup_f = node;
          }}
        />
        Female
        <br />
        <input type="button" value="submit form" onClick={this.formSumitted} />
      </form>
    );
  }
}

export default FormSubmission;
