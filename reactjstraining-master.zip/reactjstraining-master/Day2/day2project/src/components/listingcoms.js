import React from "react";

class ListingComp extends React.Component {
  /*  constructor() {
        super();

        

    } */

  render() {
    const companyListing = [
      { id: "1", location: "Olympia" },
      { id: "2", location: "RMZ" },
      { id: "3", location: "Hyderabad" }
    ];
    //  const companyListing = [{ "1": "Olympia" }, { "2": "RMZ" }, { "3": "Hyderabad" }];
    const listing = companyListing.map((currentItem, element) => {
      console.log("value of currentItem", currentItem);
      console.log("value of element", element);
      return (
        <tr key={element}>
          <td>{currentItem.id}</td>
          <td>{currentItem.location}</td>
        </tr>
      );
      //  return <tr key={element} ><td  >{currentItem.element}</td><td  >{currentItem.element}</td></tr>
    });

    return (
      <table border="1">
        <tbody>{listing}</tbody>
      </table>
    );
  }
}

export default ListingComp;
