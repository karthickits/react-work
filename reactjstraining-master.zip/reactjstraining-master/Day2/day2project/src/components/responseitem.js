import React from "react";

function ResponseItem(props) {
    console.log(props);
    return (
        <div style={{color:props.fontColor, fontSize: 14}}>
            Some Text Here for display
        </div>
    );
}

export default ResponseItem;