import React from "react";

class MyClock extends React.Component {
  constructor() {
    super();

    const currentTime = new Date().toLocaleTimeString();

    this.state = {
      curTime: currentTime
    };
  }

  render() {
    return <span>{this.state.curTime}</span>;
  }

  componentDidMount() {
    setInterval(() => {
      const currentTime = new Date().toLocaleTimeString();
      this.setState({ curTime: currentTime });
    }, 1000);
  }
}

export default MyClock;
