import React from "react";

import FormItem from "./formitem";
import ResponseItem from "./responseitem";

class AppComs extends React.Component {
  constructor() {
    super();

    this.state = {
        fontColor: "black"
    };

    this.setColor = this.setColor.bind(this);
  }

  setColor(color) {
    console.log("colcor obtianed ", color);
    this.setState({ fontColor: color });
  }

  render() {
    return (
      <div>
        <FormItem setColor={this.setColor} />
        <ResponseItem fontColor={this.state.fontColor} />
      </div>
    );
  }
}

export default AppComs;
