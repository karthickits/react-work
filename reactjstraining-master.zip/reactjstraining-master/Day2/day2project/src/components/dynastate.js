import React from "react";

class DynaState extends React.Component {
  constructor() {
    super();

    this.state = {
      fontSize: 10
    };

    this.increaseFont = this.increaseFont.bind(this);
    this.decreaseFont = this.decreaseFont.bind(this);
  }

  increaseFont() {
    this.setState(prevState => {
      let newFontSize = prevState.fontSize + 1;
      if (newFontSize > 20) newFontSize = prevState.fontSize;
      return {
        fontSize: newFontSize
      };
    });
  }

  decreaseFont() {
    this.setState(prevState => {
      let newFontSize = prevState.fontSize - 1;
      if (newFontSize <= 10) newFontSize = prevState.fontSize;

      return {
        fontSize: newFontSize
      };
    });
  }

  render() {
    return (
      <div>
        <input
          type="button"
          onClick={this.increaseFont}
          value="Increase font"
        />
        &nbsp;&nbsp;
        <input
          type="button"
          onClick={this.decreaseFont}
          value="Decrease font"
        /><br /><br />
        <span style={{ "fontSize": this.state.fontSize }}>
          Font Incrementor Sample
        </span>
      </div>
    );
  }
}

export default DynaState;
