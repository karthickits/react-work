class VzUserDetails {
  constructor() {
    this.fetching = false;
    this.userDetails = {};
    this.errorMsg = "";
  }
}

export default VzUserDetails;
