import React from "react";
import ReactDOM from "react-dom";
import logger from "redux-logger";
import thunk from "redux-thunk";
import { createStore, applyMiddleware } from "redux";
import { Provider } from "react-redux";
import { composeWithDevTools } from "redux-devtools-extension";

import VzApp from "./components/VzApp";
import vzProfileReducer from "./reducers/vzProfileReducer";
import customLogger from "./logger/customLogger";

const profileStore = createStore(
  vzProfileReducer,
  composeWithDevTools(applyMiddleware(customLogger, logger, thunk))
);

ReactDOM.render(
  <Provider store={profileStore}>
    <VzApp />
  </Provider>,
  document.getElementById("app")
);
