export default function vzProfileReducer(
  prevState = { isFetching: false, profileDetails: {}, errorMsg: "" },
  action
) {
  let newState;

  switch (action.type) {
    case "IS_FETCHING":
      newState = {
        ...prevState,
        isFetching: true,
        profileDetails: {},
        errorMsg: ""
      };
      break;
    case "FETCH_SUCCESS":
      newState = {
        ...prevState,
        isFetching: false,
        profileDetails: action.profileDetails,
        errorMsg: ""
      };
      break;
    case "FETCH_ERRORED":
      newState = {
        ...prevState,
        isFetching: false,
        profileDetails: {},
        errorMsg: action.errorMsg
      };
      break;
    default:
      newState = { ...prevState };
      break;
  }

  return newState;
}
