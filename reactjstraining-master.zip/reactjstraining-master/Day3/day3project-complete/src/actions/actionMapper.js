import axios from "axios";

export function getProfileDetailsAction(userId) {
  console.log("Inside getProfileDetailsAction: ", userId);

  let url = "https://api.github.com/users/" + userId;

  return function(dispatch) {
    dispatch({
      type: "IS_FETCHING"
    });
    axios
      .get(url)
      .then(response => {
        dispatch({
          type: "FETCH_SUCCESS",
          profileDetails: response.data,
          errorMsg: ""
        });
      })
      .catch(error => {
        dispatch({
          type: "FETCH_SUCCESS",
          profileDetails: {},
          errorMsg: error.message
        });
      });
  };
}
