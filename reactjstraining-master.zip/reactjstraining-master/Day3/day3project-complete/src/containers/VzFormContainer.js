import { connect } from "react-redux";
import VzForm from "../components/VzForm";

import { getProfileDetailsAction } from "../actions/actionMapper";

function mapStateToProps(state) {
  console.log("FormContainer.mapStateToProps: ", state);
  return {};
}

function mapDispatchToProps(dispatch) {
  console.log("FormContainer.mapDispatchToProps: ");
  return {
    getProfileDetailsAction: userId => {
      console.log("FormContainer.mapDispatchToProps.getProfileDetailsAction: ");
      // dispatch({ type: "INCREMENTOR" });
      dispatch(getProfileDetailsAction(userId));
    }, someDummyMethod: url => {
      console.log("FormContainer.mapDispatchToProps.someDummyMethod: ");
    }
  };
}

const VzFormContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(VzForm);

export default VzFormContainer;
