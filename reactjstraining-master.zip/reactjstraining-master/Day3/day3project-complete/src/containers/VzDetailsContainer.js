import { connect } from "react-redux";
import VzDetails from "../components/VzDetails";
// import VzUserDetails from "../models/VzUserDetails"

function mapStateToProps(state) {
  return {
    isFetching: state.isFetching,
    profileDetails: state.profileDetails,
    errorMsg: state.errorMsg 
  }
}

const VzDetailsContainer = connect(mapStateToProps)(VzDetails);

export default VzDetailsContainer;
