import { connect } from "react-redux";
import VzImage from "../components/VzImage";
// import VzUserDetails from "../models/VzUserDetails"

function mapStateToProps(state) {
  return {
    isFetching: state.isFetching,
    profileDetails: state.profileDetails,
    errorMsg: state.errorMsg 
  }
}

const VzImageContainer = connect(mapStateToProps)(VzImage);

export default VzImageContainer;
