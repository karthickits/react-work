import React from "react";
import VzFormContainer from "../containers/VzFormContainer";
import VzDetailsContainer from "../containers/VzDetailsContainer";
import VzImageContainer from "../containers/VzImageContainer";

class BaseApp extends React.Component {
  render() {
    return (
      <div>
        <VzFormContainer />
        <VzDetailsContainer />
        <VzImageContainer />
      </div>
    );
  }
}

export default BaseApp;
