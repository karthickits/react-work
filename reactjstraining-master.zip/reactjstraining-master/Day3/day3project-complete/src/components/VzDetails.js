import React from "react";

class VzDetails extends React.Component {
  render() {
    console.log("VzDetails.Display props: ", this.props);
    const { isFetching, profileDetails, errorMsg } = this.props;
    return (
      <div>
        {isFetching && <h3>Fetching profile details .. </h3>}

        {errorMsg && <h3>{errorMsg}</h3>}

        {profileDetails && profileDetails.name && (
          <ul>
            <li>Name: {this.props.profileDetails.name}</li>
            <li>
              Blog:{" "}
              <a href={this.props.profileDetails.blog}>
                {this.props.profileDetails.blog}
              </a>
            </li>
          </ul>
        )}
      </div>
    );
  }
}

VzDetails.defaultProps = {};

export default VzDetails;
