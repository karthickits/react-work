import React from "react";

class VzForm extends React.Component {
  render() {
    console.log("inside render", this.props);
    return (
      <div>
        <form>
          <input
            type="text"
            size={40}
            defaultValue="prakashm88"
            ref={node => {
              this.userId = node;
            }}
          />
          <br />
          <br />
          <input
            type="button"
            value="Fetch User Details"
            onClick={node => {
              this.props.getProfileDetailsAction(this.userId.value);
            }}
          />
        </form>
      </div>
    );
  }
}

export default VzForm;
