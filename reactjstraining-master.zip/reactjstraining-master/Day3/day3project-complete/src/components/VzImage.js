import React from "react";

class VzImage extends React.Component {
  render() {
    console.log("VzImage Display props: ", this.props);
    const { profileDetails } = this.props;
    return (
      <div>
        {profileDetails &&
          profileDetails.avatar_url && (
            <img src={profileDetails.avatar_url} alt={"Data Here"} />
          )}
      </div>
    );
  }
}

VzImage.defaultProps = {};

export default VzImage;
