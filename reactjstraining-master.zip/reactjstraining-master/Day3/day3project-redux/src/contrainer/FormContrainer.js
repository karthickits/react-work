import { connect } from "react-redux";
import PureForm from "../components/PureForm";

import { incrementAction, decrementAction } from "../actions/actionMapper";

function mapStateToProps(state) {
  console.log("FormContainer.mapStateToProps: ", state);
  return {};
}

function mapDispatchToProps(dispatch) {
  console.log("FormContainer.mapDispatchToProps: ");
  return {
    increment: () => {
      console.log("FormContainer.mapDispatchToProps.increment: ");
      // dispatch({ type: "INCREMENTOR" });
      dispatch(incrementAction());
    },
    decrement: () => {
      console.log("FormContainer.mapDispatchToProps.decrement: ");
      // dispatch({ type: "DECREMENTOR" });
      dispatch(decrementAction());
    }
  };
}

const FormContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(PureForm);

export default FormContainer;
