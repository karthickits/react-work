import { connect } from "react-redux";
import PureDisplay from "../components/PureDisplay";

function mapStateToProps(state) {
  return {
    count: state.count
  };
}

const DisplayContainer = connect(mapStateToProps)(PureDisplay);

export default DisplayContainer;
