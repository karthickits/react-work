import React from "react";
import ReactDOM from "react-dom";

import BaseApp from "./components/BaseApp";

import { createStore, applyMiddleware } from "redux";
import { Provider } from "react-redux";

import counterReducer from "./reducers/counterReducer"

import { composeWithDevTools } from "redux-devtools-extension";

import DisplayContainer from "./contrainer/DisplayContainer";
import FormContrainer from "./contrainer/FormContrainer";

import customLogger from "./logger/customLogger"

const counterStore = createStore(counterReducer, composeWithDevTools(applyMiddleware(customLogger)));

const counterStore2 = createStore(counterReducer, composeWithDevTools());

ReactDOM.render(<div>
  <Provider store={counterStore}>
    <BaseApp />
  </Provider>
  <Provider store={counterStore2}><div>
  <FormContrainer />
        <DisplayContainer /></div>
</Provider></div>,
  document.getElementById("app")
);
