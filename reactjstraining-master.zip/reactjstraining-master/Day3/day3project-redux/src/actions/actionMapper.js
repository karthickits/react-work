export function incrementAction() {
  return {
    type: "INCREMENTOR"
  };
}

export function decrementAction() {
  return {
    type: "DECREMENTOR"
  };
}
