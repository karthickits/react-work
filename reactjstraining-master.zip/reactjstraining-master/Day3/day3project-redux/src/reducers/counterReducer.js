export default function counterReducer(prevState = { count: 0 }, action) {

    console.log("Inside reducer" + action, prevState);

    let newState;

    switch (action.type) {
        case "INCREMENTOR":
            newState = { ...prevState, count: prevState.count + 1 };
            break;
        case "DECREMENTOR":
            newState = { ...prevState, count: prevState.count - 1 };
            break;
        default:
            newState = { ...prevState };
            break;
    }

    return newState;

}