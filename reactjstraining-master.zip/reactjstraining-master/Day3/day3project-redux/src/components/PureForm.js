import React from "react";

class Form extends React.Component {
  constructor() {
    super();
    this.increment = this.increment.bind(this);
    this.decrement = this.decrement.bind(this);
  }

  increment() {
    console.log("inside increment");
    this.props.increment();
  }
  decrement() {
    console.log("inside decrement");
    this.props.decrement();
  }

  render() {
    console.log("inside render", this.props);
    return (
      <form>
        <input type="button" value="Increment" onClick={this.increment} />
        &nbsp;&nbsp;&nbsp;{" "}
        <input type="button" value="Decrement" onClick={this.decrement} />
      </form>
    );
  }
}

export default Form;
