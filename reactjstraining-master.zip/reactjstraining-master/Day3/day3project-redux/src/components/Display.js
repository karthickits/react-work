import React from "react";
import {connect} from "react-redux"

class Display extends React.Component {
  render() {
    console.log("Display props: ", this.props);
    return <h1>{this.props.count}</h1>;
  }
}

Display.defaultProps = {
  count: 0
}

function mapStateToProps(state) {
  return {
    count: state.count
  }
}

const DisplayContainer = connect(mapStateToProps)(Display);

export default DisplayContainer;
