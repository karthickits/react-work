import React from "react";
import { connect } from "react-redux";

class Form extends React.Component {

    constructor() {
        super();
        this.increment = this.increment.bind(this);
        this.decrement = this.decrement.bind(this);
    }


  increment() {
    console.log("inside increment");
    this.props.dispatch({ type: "INCREMENTOR" });
  }
  decrement() {
    console.log("inside decrement");
    this.props.dispatch({ type: "DECREMENTOR" });
  }

    render() {
        console.log("inside render",this.props);
    return (
      <form>
        <input type="button" value="Increment" onClick={this.increment} />
        &nbsp;&nbsp;&nbsp;{" "}
        <input type="button" value="Decrement" onClick={this.decrement} />
      </form>
    );
  }
}

Form.defaultProps = {
  count: 0
};

const FormContainer = connect()(Form);

export default FormContainer;
