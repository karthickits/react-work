import React from "react";
import Form from "./Form";
import Display from "./Display";

import DisplayContainer from "../contrainer/DisplayContainer";
import FormContrainer from "../contrainer/FormContrainer";


class BaseApp extends React.Component {
  render() {
    return (
      <div>
        <Form />
        <Display />
        <br />
        <br />
        <FormContrainer />
        <DisplayContainer />
      </div>
    );
  }
}

export default BaseApp;
