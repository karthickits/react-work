import React from "react"; 

class Display extends React.Component {
  render() {
    console.log("Display props: ", this.props);
    return <h1>{this.props.count}</h1>;
  }
}

Display.defaultProps = {
  count: 0
} 

export default Display;
