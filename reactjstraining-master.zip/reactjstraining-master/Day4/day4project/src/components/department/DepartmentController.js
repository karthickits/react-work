import { connect } from "react-redux";
//import VzForm from "../components/VzForm";
import DepartmentComponent from "./DepartmentComponent"

import {
  getProfileDetailsAction,
  getDepartments
} from "../../actions/actionMapper";

function mapStateToProps(state) {
  console.log("DepartmentController.mapStateToProps: ", state);
  return {
    isFetching: state.isFetching,
    departments: state.departments,
    employees: state.employees,
    errorMsg: state.errorMsg 
  }
}

function mapDispatchToProps(dispatch) {
  console.log("DepartmentController.mapDispatchToProps: ");
  return {
    getProfileDetailsAction: userId => {
      console.log(
        "DepartmentController.mapDispatchToProps.getProfileDetailsAction: "
      );
      // dispatch({ type: "INCREMENTOR" });
      dispatch(getProfileDetailsAction(userId));
    },
    getDepartments: () => {
      console.log("DepartmentController.mapDispatchToProps.getDepartments: ");
      dispatch(getDepartments());
    }
  };
}

const DepartmentController = connect(
  mapStateToProps,
  mapDispatchToProps
)(DepartmentComponent);

export default DepartmentController;
