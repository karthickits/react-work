import React from "react";

class DepartmentComponent extends React.Component {
  componentDidMount() {
    this.props.getDepartments();
  }

  render() {
    const { isFetching, departments, errorMsg } = this.props;

    console.log("DepartmentComponent.departments: ", departments);

    const processedDepartments =
      departments && departments.length > 0
        ? departments.map((currentItem, element) => {
            console.log("value of currentItem", currentItem);
            console.log("value of element", element);
            return (
              <tr key={element}>
                <td>{currentItem.id}</td>
                <td>{currentItem.name}</td>
                <td>
                  <input
                    name="dept"
                    value={"dept_" + currentItem.id}
                    type="radio"
                  />
                </td>
              </tr>
            );
          })
        : [];

    return (
      <div className="content">
        <h1>Departments</h1>
        {isFetching && <h3>Fetching Department details .. </h3>}

        {!isFetching && errorMsg && <h3>{errorMsg}</h3>}

        {!isFetching &&
          departments &&
          departments.length > 0 && (
            <form action="">
              <div>
                <input type="button" value="Create" />
                <input type="button" value="Update" />
                <input type="button" value="Delete" />
              </div>
              <div>
                <table id="tab">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Name</th>
                      <th>&nbsp;</th>
                    </tr>
                  </thead>

                  <tbody>{processedDepartments}</tbody>
                </table>
              </div>
            </form>
          )}
      </div>
    );
  }
}

export default DepartmentComponent;
