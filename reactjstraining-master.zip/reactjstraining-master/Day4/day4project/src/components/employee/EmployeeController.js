import { connect } from "react-redux";
//import VzForm from "../components/VzForm";
import EmployeeComponent from "./EmployeeComponent"

import { 
  getEmployees, deleteEmployee
} from "../../actions/actionMapper";

function mapStateToProps(state) {
  console.log("EmployeeController.mapStateToProps: ", state);
  return {
    isFetching: state.isFetching,
    departments: state.departments,
    employees: state.employees,
    errorMsg: state.errorMsg,
    operationMessage: state.operationMessage
  }
}

function mapDispatchToProps(dispatch) {
  console.log("EmployeeController.mapDispatchToProps: ");
  return { 
    getEmployees: () => {
      console.log("EmployeeController.mapDispatchToProps.getEmployees: ");
      dispatch(getEmployees());
    },
    deleteEmployee: (empId) => {
      console.log("EmployeeController.mapDispatchToProps.deleteEmployee: ", empId);
      dispatch(deleteEmployee(empId));
    }
  };
}

const EmployeeController = connect(
  mapStateToProps,
  mapDispatchToProps
)(EmployeeComponent);

export default EmployeeController;
