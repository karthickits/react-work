import { connect } from "react-redux";
import EmployeeCreateComponent from "./EmployeeCreateComponent";

import { createEmployee } from "../../actions/actionMapper";

function mapStateToProps(state) {
  console.log("EmployeeCreateContainer.mapStateToProps: ", state);
  return {
    isFetching: state.isFetching,
    operationMessage: state.operationMessage
  };
}

function mapDispatchToProps(dispatch) {
  console.log("EmployeeCreateContainer.mapDispatchToProps: ");
  return {
    createEmployeeUser: (empName, empEmail, empPhone, empDepartment) => {
      console.log(
        "EmployeeCreateContainer.mapDispatchToProps.createEmployeeUser: ",
        empName,
        empEmail,
        empPhone,
        empDepartment
      );
      dispatch(createEmployee(empName, empEmail, empPhone, empDepartment));
    }
  };
}

const EmployeeCreateContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(EmployeeCreateComponent);

export default EmployeeCreateContainer;
