import React from 'react';

const x = 100;
x = 500;

y = 200;

if (10 === 10) {
  console.log('test');
}
