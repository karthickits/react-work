class Myclass {

    constructor(name) {
        this.name = name; 
    }

    static pi() {
        return 3.14;
    }

    sayHello() {
        console.log(`hey ${this.name}`);
    }

}

class Mychild extends Myclass {
    constructor(name) {
        super(name);
    }

    saychildHi() {
        console.log(`Chile hi ${this.name}`);
    }
}

const ins = new Myclass("prakash");
ins.sayHello(); 

const ins1 = new Mychild("prakash");
ins1.sayHello(); 
ins1.saychildHi(); 