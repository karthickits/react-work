import React from "react";

class AboutUs extends React.Component {
  render() {
    console.log(this.props);
    return <h1>About Us Page</h1>;
  }
}

export default AboutUs;
