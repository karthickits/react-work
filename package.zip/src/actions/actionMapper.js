import axios from "axios";

const REST_HOST = "http://localhost:3004";

export function getProfileDetailsAction(userId) {
  console.log("Inside getProfileDetailsAction: ", userId);

  let url = "https://api.github.com/users/" + userId;

  return function(dispatch) {
    dispatch({
      type: "IS_FETCHING"
    });
    axios
      .get(url)
      .then(response => {
        dispatch({
          type: "FETCH_SUCCESS",
          profileDetails: response.data,
          errorMsg: ""
        });
      })
      .catch(error => {
        dispatch({
          type: "FETCH_SUCCESS",
          profileDetails: {},
          errorMsg: error.message
        });
      });
  };
}

export function getDepartments() {
  console.log("Inside getDepartments");

  return function(dispatch) {
    dispatch({
      type: "IS_FETCHING"
    });
    axios
      .get(REST_HOST + "/departments")
      .then(response => {
        dispatch({
          type: "FETCH_DEPARTS_SUCCESS",
          departments: response.data,
          errorMsg: ""
        });
      })
      .catch(error => {
        dispatch({
          type: "FETCH_ERRORED",
          departments: [],
          errorMsg: error.message
        });
      });
  };
}

export function getEmployees() {
  console.log("Inside getEmployees");

  return function(dispatch) {
    dispatch({
      type: "IS_FETCHING"
    });
    axios
      .get(REST_HOST + "/employees")
      .then(response => {
        dispatch({
          type: "FETCH_EMPS_SUCCESS",
          employees: response.data,
          errorMsg: ""
        });
      })
      .catch(error => {
        dispatch({
          type: "FETCH_ERRORED",
          employees: [],
          errorMsg: error.message
        });
      });
  };
}

export function getEmployee(empId) {
  console.log("Inside getEmployee:", empId);

  return function(dispatch) {
    dispatch({
      type: "IS_FETCHING"
    });
    axios
      .get(REST_HOST + "/employees/" + empId)
      .then(response => {
        dispatch({
          type: "FETCH_EMPS_SUCCESS",
          employees: [response.data],
          errorMsg: ""
        });
      })
      .catch(error => {
        dispatch({
          type: "FETCH_ERRORED",
          employees: [],
          errorMsg: error.message
        });
      });
  };
}

export function deleteEmployee(empId) {
  console.log("Inside deleteEmployee: ", empId);
  return function(dispatch) {
    dispatch({
      type: "IS_FETCHING"
    });
    axios
      .delete(REST_HOST + "/employees/" + empId)
      .then(response => {
        dispatch({
          type: "OPERATION_SUCCESS",
          operationMessage: "User Delete Successfully !"
        });
      })
      .catch(error => {
        dispatch({
          type: "FETCH_ERRORED",
          departments: [],
          errorMsg: error.message
        });
      });
  };
}

export function createEmployee(empName, empEmail, empPhone, empDepartment) {
  console.log("Inside createEmployee: ");
  return function(dispatch) {
    dispatch({
      type: "IS_FETCHING"
    });
    axios
      .post(REST_HOST + "/employees", {
        name: empName,
        department: empDepartment,
        phone: empPhone,
        email: empEmail
      })
      .then(response => {
        dispatch({
          type: "OPERATION_SUCCESS",
          operationMessage: "User Created Successfully !"
        });
      })
      .catch(error => {
        dispatch({
          type: "FETCH_ERRORED",
          departments: [],
          errorMsg: error.message
        });
      });
  };
}

export function updateEmployee(
  empId,
  empName,
  empEmail,
  empPhone,
  empDepartment
) {
  console.log("Inside updateEmployee: ");
  return function(dispatch) {
    dispatch({
      type: "IS_FETCHING"
    });
    axios
      .put(REST_HOST + "/employees/" + empId, {
        name: empName,
        department: empDepartment,
        phone: empPhone,
        email: empEmail
      })
      .then(response => {
        dispatch({
          type: "OPERATION_SUCCESS",
          operationMessage: "User Updated Successfully !"
        });
      })
      .catch(error => {
        dispatch({
          type: "FETCH_ERRORED",
          departments: [],
          errorMsg: error.message
        });
      });
  };
}
