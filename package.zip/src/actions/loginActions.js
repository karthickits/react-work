export function loginAction(username) {
  return { type: "LOGIN", username: username };
}

export function logoutAction() {
  return { type: "LOGOUT" };
}
