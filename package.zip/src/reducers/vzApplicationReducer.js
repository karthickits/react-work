export default function vzApplicationReducer(
  prevState = {
    isFetching: false,
    departments: [],
    employees: [],
    errorMsg: "",
    operationMessage: "",
    loggedIn: false,
    username: ""
  },
  action = "IDLE"
) {
  let newState;

  switch (action.type) {
    case "IS_FETCHING":
      newState = {
        ...prevState,
        isFetching: true,
        departments: [],
        employees: [],
        errorMsg: "",
        operationMessage: ""
      };
      break;
    case "FETCH_DEPARTS_SUCCESS":
      newState = {
        ...prevState,
        isFetching: false,
        departments: action.departments,
        employees: [],
        errorMsg: "",
        operationMessage: ""
      };
      break;
    case "FETCH_EMPS_SUCCESS":
      newState = {
        ...prevState,
        isFetching: false,
        departments: [],
        employees: action.employees,
        errorMsg: "",
        operationMessage: ""
      };
      break;
    case "FETCH_ERRORED":
      newState = {
        ...prevState,
        isFetching: false,
        departments: [],
        employees: [],
        errorMsg: action.errorMsg,
        operationMessage: ""
      };
      break;
    case "OPERATION_SUCCESS":
      newState = {
        ...prevState,
        isFetching: false,
        departments: [],
        employees: [],
        errorMsg: "",
        operationMessage: action.operationMessage
      };
      break;
    case "LOGIN":
      newState = { ...prevState, loggedIn: true, username: action.username };
      break;
    case "LOGOUT":
      newState = { ...prevState, loggedIn: false, username: "" };
      break;
    default:
      newState = { ...prevState };
      break;
  }

  return newState;
}
