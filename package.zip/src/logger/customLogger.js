/*

export default function customLogger(store) {
    return function next(return function action(action){
        return action;
    }) 
}

*/

export default function customLoggers(store) {
  return function next(next) {
    return function action(action) {
      //console.log("######## ", store);
     // console.log("######## ", action);
      //console.log("######## ", next);
      const returnVal = next(action);
     // console.log("######## ", store);
      return returnVal;
    };
  };
}

/*const customLogger = store => next => action => {
    console.log("######## ", store);
    console.log("######## ", action);
    console.log("######## ", next);
    const returnVal = next(action);
    console.log("######## ", store);
    return returnVal;
}

export default customLogger;*/
