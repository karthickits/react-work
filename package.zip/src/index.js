import React from "react";
import ReactDOM from "react-dom";
import logger from "redux-logger";
import thunk from "redux-thunk";
import { createStore, applyMiddleware } from "redux";
import { Provider } from "react-redux";
import { composeWithDevTools } from "redux-devtools-extension";
import { BrowserRouter } from "react-router-dom";

import MainApplication from "./components/MainApplication";
import vzApplicationReducer from "./reducers/vzApplicationReducer";
import customLogger from "./logger/customLogger";

import "./index.css";

const employeeStore = createStore(
  vzApplicationReducer,
  composeWithDevTools(applyMiddleware(customLogger, logger, thunk))
);

ReactDOM.render(
  <BrowserRouter>
    <Provider store={employeeStore}>
      <MainApplication />
    </Provider>
  </BrowserRouter>,
  document.getElementById("app")
);
