import React from "react";
import { connect } from "react-redux";
import { loginAction } from "../actions/loginActions";
import { Redirect } from "react-router-dom";

class LoginComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      loginSuccess: false
    };

    this.submitForm = this.submitForm.bind(this);
  }

  submitForm() {
    if (this.username.value === "") {
      alert("Enter Username!");
      return;
    }

    if (this.password.value === "") {
      alert("Enter Password!");
      return;
    }

    this.setState({
      username: this.username.value,
      password: this.password.value
    });

    const submitValues = {
      un: this.username.value,
      pwd: this.password.value
    };

    console.log("creds: ", submitValues);

    if (submitValues.un === "test" && submitValues.pwd === "test") {
      this.props.dispatch(loginAction(submitValues.un));
      this.setState({ loginSuccess: true, username: submitValues.un });
    } else {
      alert("Invalid crdentials! Enter correct Username & Password");
    }
  }

  render() {
    if (this.state.loginSuccess) return <Redirect to="/" />;
    return (
      <div>
        <h1>Login</h1>
        <form action="/department">
          <div className="form-input">
            <label>Username:</label>
            <input
              type="text"
              ref={node => {
                this.username = node;
              }}
            />
          </div>

          <div className="form-input">
            <label>Password:</label>
            <input
              type="password"
              ref={node => {
                this.password = node;
              }}
            />
          </div>

          <div className="form-input">
            <input type="submit" value="Login" onClick={this.submitForm} />
            <input type="button" value="Reset" />
          </div>
        </form>
      </div>
    );
  }
}

//export default LoginComponent;

function mapPropsToState(state) {
  return {
    loggedIn: state.loggedIn,
    username: state.username
  };
}

export default connect(mapPropsToState)(LoginComponent);
