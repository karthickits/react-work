import React from "react";
import { Switch, Route } from "react-router-dom";
import LoginComponent from "./LoginComponent";
import LogoutComponent from "./LogoutComponent";
import DepartmentController from "./department/DepartmentController";
import EmployeeController from "./employee/EmployeeController";
import EmployeeCreateContainer from "./employee/EmployeeCreateContainer";
import EmployeeUpdateContainer from "./employee/EmployeeUpdateContainer";
import MenuComponent from "./common/MenuComponent";
import HeaderComponent from "./common/HeaderComponent";

import PrivateRoute from "../util/PrivateRoute";

class MainApplication extends React.Component {
  render() {
    return (<div className="main"><HeaderComponent/><MenuComponent />
      <section className="content">
        <Switch>
          <PrivateRoute path="/" exact component={EmployeeController} />
          <Route path="/login" exact component={LoginComponent} />
          <PrivateRoute path="/department" exact component={DepartmentController} />
          <PrivateRoute path="/employee" exact  component={EmployeeController} />
          <PrivateRoute path="/employee/add" exact component={EmployeeCreateContainer} />
          <PrivateRoute path="/employee/udpate" component={EmployeeUpdateContainer} />
          <Route path="/logout"  component={LogoutComponent} />
          <Route
            path="*"
            render={() => {
              return <h1>404 - Page Not Found !</h1>;
            }}
          />
        </Switch>
      </section></div>
    );
  }
}

export default MainApplication;
