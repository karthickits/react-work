import React from "react";
import { connect } from "react-redux";

class HeaderComponent extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      loggedId: this.props.loggedIn,
      username: this.props.username
    };
  }
  render() {
    return (
      <header className="header">
        <h1>Employee Database</h1>
        <span style={{ color: "white", float: "right" }}>
          Welcome {this.props.username}
        </span>
      </header>
    );
  }
}

//export default HeaderComponent;

function mapPropsToState(state) {
  return {
    loggedIn: state.loggedIn,
    username: state.username
  };
}

export default connect(mapPropsToState)(HeaderComponent);
