import React from "react";
import { Link } from "react-router-dom";

class EmployeeComponent extends React.Component {
  constructor() {
    super();
    this.reloadPage = this.reloadPage.bind(this);
  }

  reloadPage() {
    this.props.getEmployees();
  }

  render() {
    const { isFetching, errorMsg, operationMessage } = this.props;

    return (
      <div className="content">
        <h1>Create Employee</h1>
        {isFetching && <h3>Fetching employee details .. </h3>}

        {!isFetching && errorMsg && <h3>{errorMsg}</h3>}

        {!isFetching &&
          operationMessage && (
            <div>
              <h3>{operationMessage}</h3>
              <br />
              {/* <Link to={"/employee?" + new Date().getTime() }>Back to Employees</Link> */}

              <Link to="/employee">
                <input type="button" value="Back" />
              </Link>
            </div>
          )}

        {!isFetching &&
          !operationMessage && (
            <form action="">
              Name:{" "}
              <input
                type="text"
                name="empName"
                defaultValue={"User1" + new Date().getTime()}
                ref={node => {
                  this.empName = node;
                }}
              />{" "}
              <br />
              Email:{" "}
              <input
                type="text"
                name="empEmail"
                defaultValue={"User1" + new Date().getTime() + "@email.com"}
                ref={node => {
                  this.empEmail = node;
                }}
              />{" "}
              <br />
              Phone:{" "}
              <input
                type="text"
                name="empPhone"
                defaultValue={new Date().getTime()}
                ref={node => {
                  this.empPhone = node;
                }}
              />{" "}
              <br />
              Department:{" "}
              <input
                type="text"
                name="empDepartment"
                defaultValue="Learning &amp; Development"
                ref={node => {
                  this.empDepartment = node;
                }}
              />{" "}
              <br />
              <br />
              <input
                type="button"
                value="Submit"
                onClick={node => {
                  this.props.createEmployeeUser(
                    this.empName.value,
                    this.empEmail.value,
                    this.empPhone.value,
                    this.empDepartment.value
                  );
                }}
              />
            </form>
          )}
      </div>
    );
  }
}

export default EmployeeComponent;
