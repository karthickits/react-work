import React from "react";
import { Link } from "react-router-dom";

class EmployeeComponent extends React.Component {
  constructor() {
    super();
     this.state = {
      selectedEmployeeId: 0
    };
    this.optionSelected = this.optionSelected.bind(this);
    this.deleteUserholder = this.deleteUserholder.bind(this);
    this.reloadPage = this.reloadPage.bind(this);
  }

  componentDidMount() {
    this.props.getEmployees();
  }

  reloadPage() {
    this.props.getEmployees();
  }

  deleteUserholder() {
    console.log("deleteUserholder: ");
    console.log("selectedemp: ", this.selectedEmployeeId);
    // console.log("selectedemp state: ", this.state.selectedEmployeeId);
    this.props.deleteEmployee(this.selectedEmployeeId);
  }

  optionSelected(eventObj) {
    console.log("optionSelected: ", eventObj.target.value);
    this.selectedEmployeeId = eventObj.target.value;
    this.setState({ selectedEmployeeId: eventObj.target.value });
  }

  render() {
    const { isFetching, employees, errorMsg, operationMessage } = this.props;

    console.log("EmployeeComponent.employees: ", employees);

    const processedEmployees =
      employees && employees.length > 0
        ? employees.map((currentItem, element) => {
            console.log("value of currentItem", currentItem);
            console.log("value of element", element);
            return (
              <tr key={element}>
                <td>{currentItem.id}</td>
                <td>{currentItem.name}</td>
                <td>{currentItem.email}</td>
                <td>{currentItem.phone}</td>
                <td>{currentItem.department}</td>
                <td>
                  <input
                    name="emps"
                    value={currentItem.id}
                    type="radio"
                    onChange={this.optionSelected}
                  />
                </td>
              </tr>
            );
          })
        : [];

    return (
      <div className="content">
        <h1>Employees</h1>

        {isFetching && <h3>Fetching employee details .. </h3>}

        {!isFetching && errorMsg && <h3>{errorMsg}</h3>}

        {!isFetching &&
          operationMessage && (
            <div>
              <h3>{operationMessage}</h3>
              <br />
              {/* <Link to={"/employee?" + new Date().getTime() }>Back to Employees</Link> */}
              <input type="button" value="Back" onClick={this.reloadPage} />
            </div>
          )}

        {!isFetching &&
          employees &&
          employees.length > 0 && (
            <form action="">
              <div>
                <Link to="/employee/add">
                  <input type="button" value="Create" />
                </Link>
                <Link to={"/employee/udpate?empId=" + this.state.selectedEmployeeId}>
                  <input type="button" value="Update" />
                </Link>
                <input
                  type="button"
                  value="Delete"
                  onClick={this.deleteUserholder}
                />
              </div>
              <div>
                <table id="tab">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>department</th>
                      <th>&nbsp;</th>
                    </tr>
                  </thead>

                  <tbody>{processedEmployees}</tbody>
                </table>
              </div>
            </form>
          )}
      </div>
    );
  }
}

export default EmployeeComponent;
