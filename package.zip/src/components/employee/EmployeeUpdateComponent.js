import React from "react";
import { Link } from "react-router-dom";

class EmployeeUpdateComponent extends React.Component {
  constructor(props) {
    super(props);
    console.log("Location id: ", this.props.location);
    this.selectedEmployeeId = this.props.location.search.slice(7);
    this.state = {
      selectedEmployeeId: this.selectedEmployeeId
    };

    console.log("Obtained id: ", this.selectedEmployeeId);

    if (this.selectedEmployeeId) {
      this.props.getEmployee(this.selectedEmployeeId);
    }
  }

  render() {
    const { isFetching, errorMsg, employees, operationMessage } = this.props;

    let employee = {name: "", email: "", department: "", phone: ""};

    if (employees && employees.length === 1) {
      employee = employees[0];
    }

    return (
      <div className="content">
        <h1>Update Employee</h1>
        {isFetching && <h3>Fetching employee details .. </h3>}

        {!isFetching && errorMsg && <h3>{errorMsg}</h3>}

        {!isFetching &&
          operationMessage && (
            <div>
              <h3>{operationMessage}</h3>
              <br />
              {/* <Link to={"/employee?" + new Date().getTime() }>Back to Employees</Link> */}

              <Link to="/employee">
                <input type="button" value="Back" />
              </Link>
            </div>
          )}

        {!isFetching &&
          !operationMessage && (
            <form action="">
              Name:{" "}
              <input
                type="text"
                name="empName"
                defaultValue={employee.name}
                ref={node => {
                  this.empName = node;
                }}
              />{" "}
              <br />
              Email:{" "}
              <input
                type="text"
                name="empEmail"
                defaultValue={employee.email}
                ref={node => {
                  this.empEmail = node;
                }}
              />{" "}
              <br />
              Phone:{" "}
              <input
                type="text"
                name="empPhone"
                defaultValue={employee.phone}
                ref={node => {
                  this.empPhone = node;
                }}
              />{" "}
              <br />
              Department:{" "}
              <input
              type="text"
              name="empDepartment"
              defaultValue={employee.department}
                ref={node => {
                  this.empDepartment = node;
                }}
              />{" "}
              <br />
              <br />
              <input
                type="button"
                value="Submit"
                onClick={node => {
                  this.props.updateEmployee(
                    this.selectedEmployeeId,
                    this.empName.value,
                    this.empEmail.value,
                    this.empPhone.value,
                    this.empDepartment.value
                  );
                }}
              /> &nbsp; &nbsp; <Link to="/employee">
              <input type="button" value="Back" />
            </Link>
            </form>
          )}
      </div>
    );
  }
}

export default EmployeeUpdateComponent;
