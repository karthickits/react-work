import { connect } from "react-redux";
import EmployeeUpdateComponent from "./EmployeeUpdateComponent";

import { getEmployee, updateEmployee } from "../../actions/actionMapper";

function mapStateToProps(state) {
  console.log("EmployeeCreateContainer.mapStateToProps: ", state);
  return {
    isFetching: state.isFetching,
    employees: state.employees,
    errorMsg: state.errorMsg,
    operationMessage: state.operationMessage
  };
}

function mapDispatchToProps(dispatch) {
  console.log("EmployeeCreateContainer.mapDispatchToProps: ");
  return {
    getEmployee: selectedEmployeeId => {
      console.log(
        "EmployeeCreateContainer.mapDispatchToProps.createEmployeeUser: ",
        selectedEmployeeId
      );
      dispatch(getEmployee(selectedEmployeeId));
    },
    updateEmployee: (empId, empName, empEmail, empPhone, empDepartment) => {
      console.log(
        "EmployeeCreateContainer.mapDispatchToProps.createEmployeeUser: "
      );
      dispatch(
        updateEmployee(empId, empName, empEmail, empPhone, empDepartment)
      );
    }
  };
}

const EmployeeUpdateContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(EmployeeUpdateComponent);

export default EmployeeUpdateContainer;
